<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="flex flex-row-reverse font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('داشبورد')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class=" py-12">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create',\App\Models\Restaurant::class)): ?>
        <div class="flex flex-row-reverse w-1/2 mt-3 mx-auto text-3xl">
            <a href="<?php echo e(route('seller.order.index')); ?>" class="mx-2">
                <button type="submit"
                        class="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 m-1 border border-blue-500 hover:border-transparent rounded">
                    سفارشات غذا
                </button>
            </a>

            <a href="<?php echo e(route('seller.food.index')); ?>" class="mx-2">
                <button type="submit"
                        class="bg-orange-300 hover:bg-orange-500 text-blue-700 font-semibold hover:text-white py-2 px-4 m-1 border border-blue-500 hover:border-transparent rounded">
                    غذاها
                </button>
            </a>
        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\laravel projects\snapfoodclone\resources\views/dashboard.blade.php ENDPATH**/ ?>