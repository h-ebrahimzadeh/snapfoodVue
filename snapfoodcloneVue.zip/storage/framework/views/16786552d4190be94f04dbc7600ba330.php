<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet"/>
    
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"/>
    
    <link href="https://static.neshan.org/sdk/openlayers/5.3.0/ol.css" rel="stylesheet" type="text/css">
    <script
        src="https://cdn.polyfill.io/v2/polyfill.min.js?features=requestAnimationFrame,Element.prototype.classList,URL"></script>
    <script src="https://static.neshan.org/sdk/openlayers/5.3.0/ol.js" type="text/javascript"></script>

    <link href="https://static.neshan.org/sdk/leaflet/1.4.0/leaflet.css" rel="stylesheet" type="text/css">
    <script src="https://static.neshan.org/sdk/leaflet/1.4.0/leaflet.js" type="text/javascript">


    </script>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

</head>
<body style="font-family: Vazir;" class=" antialiased w-full" id="app">

<div class="min-h-screen bg-gray-100">
    
    <?php if(auth()->user()): ?>

        <div class="grid grid-cols-2 justify-items-start place-items-center bg-orange-500">
            <navigation class="mx-10 col-start-1 text-xl ml-10 m-1 "
                        user-name="<?php echo e(Auth::user()->name); ?>"></navigation>
            <div class="col-start-4 justify-self-end  mx-4">
                <?php if(auth()->user()->role_id == \App\Models\Role::IS_SELLER): ?>
                    <div>
                        <a class="mx-3 hover:drop-shadow-2xl" href="<?php echo e(route('dashboard')); ?>">داشبورد</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create',\App\Models\Restaurant::class)): ?>
                            <a class="mx-3 hover:drop-shadow-2xl" href="<?php echo e(route('seller.restaurant.create')); ?>">رستوران
                                جدید</a>
                        <?php endif; ?>
                        <a class="mx-3 hover:drop-shadow-2xl" href="<?php echo e(route('seller.restaurant.index')); ?>">رستوران ها</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create',\App\Models\Food::class)): ?>
                            <a class="mx-3 hover:drop-shadow-2xl" href="<?php echo e(route('seller.food.create')); ?>">غذای جدید</a>
                        <?php endif; ?>
                        <a class="mx-3 hover:drop-shadow-2xl" href="<?php echo e(route('seller.food.index')); ?>">غذاها</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create',\App\Models\Coupon::class)): ?>
                            <a class="mx-3 hover:drop-shadow-2xl" href="<?php echo e(route('seller.coupon.create')); ?>">کوپن جدید</a>
                        <?php endif; ?>
                        <a class="mx-3 hover:drop-shadow-2xl" href="<?php echo e(route('seller.coupon.index')); ?>">کوپن ها</a>
                    </div>
                <?php endif; ?>
                <?php if(auth()->user()->role_id==\App\Models\Role::IS_ADMIN): ?>
                    <a class="mr-3  border-l border-slate-500 p-1 hover:drop-shadow-md "
                       href="<?php echo e(route('admin.restaurant_categories.create')); ?>">دسته بندی رستوران جدید</a>

                    <a class="mr-3  border-l border-slate-500 p-1 hover:drop-shadow-md "
                       href="<?php echo e(route('admin.restaurant_categories.index')); ?>">دسته بندی رستوران ها</a>

                    <a class="mr-3  border-l border-slate-500 p-1 hover:drop-shadow-md "
                       href="<?php echo e(route('admin.food_categories.create')); ?>">دسته بندی غذای جدید</a>

                    <a class="mr-3  border-l border-slate-500 p-1 hover:drop-shadow-md "
                       href="<?php echo e(route('admin.food_categories.index')); ?>">دسته بندی غذاها</a>

                    <a class="mr-3  border-l border-slate-500 p-1 hover:drop-shadow-md "
                       href="<?php echo e(route('admin.comments.index')); ?>">کامنت ها</a>
                <?php endif; ?>

            </div>
        </div>
    <?php endif; ?>

    

    <!-- Page Heading -->
    <?php if(isset($header)): ?>
        <header class="bg-white shadow">
            <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                <?php echo e($header); ?>

            </div>
        </header>
    <?php endif; ?>

    <!-- Page Content -->
    <main class="w-11/12 mx-auto">
        <?php echo e($slot); ?>

    </main>
</div>


</body>

</html>
<?php /**PATH C:\laravel-projects\snapfoodcloneVue\resources\views/layouts/app.blade.php ENDPATH**/ ?>