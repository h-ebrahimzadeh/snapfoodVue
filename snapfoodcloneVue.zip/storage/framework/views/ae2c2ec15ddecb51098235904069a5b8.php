<nav x-data="{ open: false }" class="font-Yekan bg-white border-b border-gray-100">
    <!-- Primary Navigation Menu -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex">
                <!-- Logo -->
                <div class="shrink-0 flex items-center">
                    <a href="<?php echo e(route('main')); ?>">
صفحه اصلی
                    </a>
                </div>

            </div>
        </div>
</div>














































</nav>
<?php /**PATH D:\laravel projects\snapfoodclone\resources\views/layouts/navigationGuest.blade.php ENDPATH**/ ?>