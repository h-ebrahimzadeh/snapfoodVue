<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('create food')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class=" w-1/2 mt-3 mx-auto ">
            <form action="<?php echo e(route('seller.food.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="mb-6">
                        <label class="block mb-2 text-sm font-medium text-green-700 dark:text-green-500">نام</label>
                        <input type="text"
                               name="name"
                               id="<?php if(empty($errors->first('name'))): ?> success <?php else: ?> error  <?php endif; ?>"
                               class="<?php if(!empty($errors->first('name'))): ?> bg-green-50 border border-green-500 text-green-900 dark:text-green-400 placeholder-green-700 dark:placeholder-green-500 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5 dark:bg-gray-700 dark:border-green-500
                                <?php else: ?> bg-slate-50 border border-slate-500 text-slate-900 dark:text-slate-400 placeholder-slate-700 dark:placeholder-slate-500 text-sm rounded-lg focus:ring-slate-500 focus:border-slate-500 block w-full p-2.5 dark:bg-gray-700 dark:border-slate-500
                                 <?php endif; ?>"
                                value="<?php echo e(old('name')); ?>">
                                <p class="mt-2 text-sm <?php if(empty($errors->first('name'))): ?> text-green-600        dark:text-green-500
                                    <?php else: ?> text-red-600 dark:text-red-500 <?php endif; ?>"><?php echo e($errors->first('name')); ?>

                                </p>
                    </div>

                <div class="mb-6">
                        <label class="block mb-2 text-sm font-medium text-green-700 dark:text-green-500">دسته بندی غذا</label>
                        <select  name="food_category"
                                id="<?php if(empty($errors->first('food_category'))): ?> success <?php else: ?> error  <?php endif; ?>"
                                class="<?php if(!empty($errors->first('food_category'))): ?> bg-green-50 border border-green-500 text-green-900 dark:text-green-400 placeholder-green-700 dark:placeholder-green-500 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5 dark:bg-gray-700 dark:border-green-500
                           <?php else: ?> bg-slate-50 border border-slate-500 text-slate-900 dark:text-slate-400 placeholder-slate-700 dark:placeholder-slate-500 text-sm rounded-lg focus:ring-slate-500 focus:border-slate-500 block w-full p-2.5 dark:bg-gray-700 dark:border-slate-500
                           <?php endif; ?>">

                            <option   value="" disabled selected>یکی را انتخاب کنید...</option>
                            <?php $__currentLoopData = $food_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($food_category->id); ?>"><?php echo e($food_category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                <div class="mb-6">
                    <label class="block mb-2 text-sm font-medium text-green-700 dark:text-green-500">مواد اولیه</label>
                    <input type="text"
                           name="materials"
                           placeholder="مواد اولیه"
                           id="<?php if(empty($errors->first('materials'))): ?> success <?php else: ?> error  <?php endif; ?>"
                           class="<?php if(!empty($errors->first('materials'))): ?> bg-green-50 border border-green-500 text-green-900 dark:text-green-400 placeholder-green-700 dark:placeholder-green-500 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5 dark:bg-gray-700 dark:border-green-500
                                <?php else: ?> bg-slate-50 border border-slate-500 text-slate-900 dark:text-slate-400 placeholder-slate-700 dark:placeholder-slate-500 text-sm rounded-lg focus:ring-slate-500 focus:border-slate-500 block w-full p-2.5 dark:bg-gray-700 dark:border-slate-500
                                 <?php endif; ?>"
                           value="<?php echo e(old('material')); ?>">
                            <p class="mt-2 text-sm <?php if(empty($errors->first('materials'))): ?> text-green-600        dark:text-green-500
                                    <?php else: ?> text-red-600 dark:text-red-500 <?php endif; ?>"><?php echo e($errors->first('material')); ?>

                            </p>
                </div>

                <div class="mb-6">
                    <label class="block mb-2 text-sm font-medium text-green-700 dark:text-green-500">قیمت</label>
                    <input type="text"
                           name="price"
                           id="<?php if(empty($errors->first('price'))): ?> success <?php else: ?> error  <?php endif; ?>"
                           class="<?php if(!empty($errors->first('price'))): ?> bg-green-50 border border-green-500 text-green-900 dark:text-green-400 placeholder-green-700 dark:placeholder-green-500 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5 dark:bg-gray-700 dark:border-green-500
                                <?php else: ?>
                                bg-slate-50 border border-slate-500 text-slate-900 dark:text-slate-400 placeholder-slate-700 dark:placeholder-slate-500 text-sm rounded-lg focus:ring-slate-500 focus:border-slate-500 block w-full p-2.5 dark:bg-gray-700 dark:border-slate-500
                                 <?php endif; ?>"
                           value="<?php echo e(old('price')); ?>">
                    <p class="mt-2 text-sm <?php if(empty($errors->first('price'))): ?> text-green-600        dark:text-green-500
                                    <?php else: ?> text-red-600 dark:text-red-500 <?php endif; ?>"><?php echo e($errors->first('price')); ?>

                    </p>
                </div>

                <div class="mb-6">
                    <label class="block mb-2 text-sm font-medium text-green-700 dark:text-green-500">کوپن</label>
                    <select name="coupon"
                            id="<?php if(empty($errors->first('coupon'))): ?> success <?php else: ?> error  <?php endif; ?>"
                            class="<?php if(!empty($errors->first('coupon'))): ?>
                             bg-slate-50 border border-slate-500 text-slate-900 dark:text-slate-400 placeholder-slate-700 dark:placeholder-slate-500 text-sm rounded-lg focus:ring-slate-500 focus:border-slate-500 block w-full p-2.5 dark:bg-gray-700 dark:border-slate-500
                           <?php else: ?>
                           bg-slate-50 border border-slate-500 text-slate-900 dark:text-slate-400 placeholder-slate-700 dark:placeholder-slate-500 text-sm rounded-lg focus:ring-slate-500 focus:border-slate-500 block w-full p-2.5 dark:bg-gray-700 dark:border-slate-500
                           <?php endif; ?>">

                        <option value="" disabled>یکی را انتخاب کنید...</option>
                        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($coupon->id); ?>"><?php echo e($coupon->code); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>


                <div class="mb-6">

                    <label class="block mb-2 text-sm font-medium text-black-700 dark:text-green-500">فود پارتی</label>
                    <select dir="rtl" name="food_party"
                            id="<?php if(empty($errors->first('food_party'))): ?> success <?php else: ?> error  <?php endif; ?>"
                            class="<?php if(! empty($errors->first('food_party'))): ?>
                               bg-slate-50 border border-slate-500 text-slate-900 dark:text-slate-400 placeholder-slate-700 dark:placeholder-slate-500 text-sm rounded-lg focus:ring-slate-500 focus:border-slate-500 block w-full p-2.5 dark:bg-gray-700 dark:border-slate-500
                           <?php else: ?>
                           bg-slate-50 border border-slate-500 text-slate-900 dark:text-slate-400 placeholder-slate-700 dark:placeholder-slate-500 text-sm rounded-lg focus:ring-slate-500 focus:border-slate-500 block w-full p-2.5 dark:bg-gray-700 dark:border-slate-500
                           <?php endif; ?>">

                        <option value="" disabled selected>یکی را انتخاب کنید...</option>
                        <?php $__currentLoopData = $food_parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food_party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($food_party->id); ?>"><?php echo e($food_party->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-6">
                    <label class="block mb-2 text-sm font-medium text-green-700 dark:text-green-500">رستوران</label>
                    <select name="restaurant"
                            id="<?php if(empty($errors->first('restaurant'))): ?> success <?php else: ?> error  <?php endif; ?>"
                            class="<?php if(!empty($errors->first('restaurant'))): ?> bg-green-50 border border-green-500 text-green-900 dark:text-green-400 placeholder-green-700 dark:placeholder-green-500 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5 dark:bg-gray-700 dark:border-green-500
                           <?php else: ?> bg-slate-50 border border-slate-500 text-slate-900 dark:text-slate-400 placeholder-slate-700 dark:placeholder-slate-500 text-sm rounded-lg focus:ring-slate-500 focus:border-slate-500 block w-full p-2.5 dark:bg-gray-700 dark:border-slate-500
                           <?php endif; ?>">

                        <option value="" disabled>یکی را انتخاب کنید...</option>
                        <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($restaurant->id); ?>"><?php echo e($restaurant->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>


                <div class="felx mb-6">
                    <label class="block mb-2 text-sm font-medium text-green-700 dark:text-green-500">تصویر غذا</label>

                    <label for="image">تصویر دلخواه را انتخاب کنید</label>
                    <input  id="image"
                              class="block mx-auto w-full text-sm text-slate-500
                            file:border-1 file:text-center
                                    file:text-sm file:font-semibold
                                    file:bg-violet-50 file:text-violet-700
                                    hover:file:bg-violet-100
                       "  type="file" name="image">


                </div>





                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    ثبت
                </button>
            </form>
        </div>
    </div>

    <script>
        const input = document.getElementById("image");
        const preview = document.querySelector(".preview");


        input.style.opacity = 0;


        input.addEventListener("change", updateImageDisplay);

        function updateImageDisplay() {
            while (preview.firstChild) {
                preview.removeChild(preview.firstChild);
            }

            const curFiles = input.files;
            if (curFiles.length === 0) {
                const para = document.createElement("p");
                para.textContent = "No files currently selected for upload";
                preview.appendChild(para);
            } else {
                const list = document.createElement("ol");
                preview.appendChild(list);

                for (const file of curFiles) {
                    const listItem = document.createElement("li");
                    const para = document.createElement("p");
                    if (validFileType(file)) {
                        para.textContent = `File name ${file.name}, file size ${returnFileSize(
                            file.size,
                        )}.`;
                        const image = document.createElement("img");
                        image.src = URL.createObjectURL(file);

                        listItem.appendChild(image);
                        listItem.appendChild(para);
                    } else {
                        para.textContent = `File name ${file.name}: Not a valid file type. Update your selection.`;
                        listItem.appendChild(para);
                    }

                    list.appendChild(listItem);
                }
            }
        }

        // https://developer.mozilla.org/en-US/docs/Web/Media/Formats/Image_types
        const fileTypes = [
            "image/apng",
            "image/bmp",
            "image/gif",
            "image/jpeg",
            "image/pjpeg",
            "image/png",
            "image/svg+xml",
            "image/tiff",
            "image/webp",
            "image/x-icon",
        ];

        function validFileType(file) {
            return fileTypes.includes(file.type);
        }

        function returnFileSize(number) {
            if (number < 1024) {
                return `${number} bytes`;
            } else if (number >= 1024 && number < 1048576) {
                return `${(number / 1024).toFixed(1)} KB`;
            } else if (number >= 1048576) {
                return `${(number / 1048576).toFixed(1)} MB`;
            }
        }

    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laravel-projects\snapfoodcloneVue\resources\views/food/create.blade.php ENDPATH**/ ?>