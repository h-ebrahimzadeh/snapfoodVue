<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-right">
            <?php echo e(__('رستوران ها')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <?php $i=1 ?>
    <div class="py-12">
        <div class="relative overflow-x-auto w-full mx-md-2 text-lg">

            <table dir="rtl" class="w-3/4 mx-auto text-lg table-auto">
                <thead class=" text-gray-700 uppercase bg-gray-100">
                <tr class="">
                    <th class="whitespace-nowrap px-6 py-3 text-center rounded-l-lg">ردیف</th>

                    <th class="whitespace-nowrap px-6 py-3 text-center rounded-l-lg">نام</th>
                    <th class="whitespace-nowrap px-6 py-3 text-center rounded-l-lg">دسته بندی رستوران</th>
                    <th class="whitespace-nowrap px-6 py-3 text-center rounded-l-lg">شماره همراه</th>
                    <th class="whitespace-nowrap px-6 py-3 text-center rounded-l-lg">آدرس</th>
                    <th class="whitespace-nowrap px-6 py-3 text-center rounded-l-lg">شماره حساب</th>

                    <th class="whitespace-nowrap px-6 py-3 text-center"></th>
                    <th class="whitespace-nowrap px-6 py-3 text-center"></th>
                    <th class="whitespace-nowrap px-6 py-3 text-center rounded-r-lg"></th>

                </tr>
                </thead>
                <tbody>
                
                <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b even:bg-blue-200">
                        <td class="whitespace-nowrap px-6 py-3 text-center"><?php echo e($i++); ?></td>
                        <td class="whitespace-nowrap px-6 py-3 text-center"><?php echo e($restaurant->name); ?></td>

                        <td class="whitespace-nowrap px-6 py-3 text-center"><?php echo e($restaurant->restaurantCategory->name); ?></td>
                        <td class="whitespace-nowrap px-6 py-3 text-center"><?php echo e($restaurant->phone_number); ?></td>
                        <td class="whitespace-nowrap px-6 py-3 text-center"><?php echo e($restaurant->address); ?></td>
                        <td class="whitespace-nowrap px-6 py-3 text-center"><?php echo e($restaurant->account_number); ?></td>


                        
                        
                        
                        
                        
                        
                        
                        
                        <td class="whitespace-nowrap px-3 py-3 text-center">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$restaurant)): ?>
                                <a href="<?php echo e(route('seller.restaurant.edit',$restaurant->id)); ?>" class="mx-2">
                                    <button type="submit"
                                            class="bg-transparent hover:bg-green-500 text-green-700 font-semibold hover:text-white py-2 px-4 m-1 border border-green-500 hover:border-transparent rounded">
                                        ویرایش
                                    </button>
                                </a>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-3 py-3 text-center">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$restaurant)): ?>
                                <form action="<?php echo e(route('seller.restaurant.destroy',$restaurant->id)); ?>"
                                      method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit"
                                            class="bg-transparent hover:bg-red-500 text-red-700 font-semibold hover:text-white py-2 px-4 m-1 border border-red-500 hover:border-transparent rounded">
                                        حذف
                                    </button>


                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laravel-projects\snapfoodcloneVue\resources\views/restaurant/index.blade.php ENDPATH**/ ?>