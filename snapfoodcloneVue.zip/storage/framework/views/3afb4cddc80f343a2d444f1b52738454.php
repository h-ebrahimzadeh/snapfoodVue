<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Snap food clone</title>
    <style>
        @font-face {
            font-family: Yekan;
            src: url('/fonts/Yekan.eot');
            src: url('/fonts/Yekan.eot?#iefix') format('Yekan-opentype'),
            url('/fonts/Yekan.woff') format('woff'),
            url('/fonts/Yekan.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
        }
    </style>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body style="font-family: Yekan;" class="bg-blue-300">
<div>

</div>
<div
    class="flex flex-row-reverse space-x-3 space-x-reverse items-center  w-full h-16 fixed top-0 right-0  px-6 bg-blue-400 text-right">


<div class="flex flex-row space-x-3">
    <?php if(Route::has('login')): ?>

        <?php if(auth()->guard()->check()): ?>
            <div>
                <a href="<?php echo e(url('/dashboard')); ?>"
                   class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">داشبورد</a>
            </div>

        <?php else: ?>
            <div>
                <a href="<?php echo e(route('login')); ?>"
                   class="mX-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">
                    <button
                        class="bg-orange-500 hover:bg-orange-700 text-white font-bold py-2 px-4 border border-orange-700 rounded">
                        ورود
                    </button>
                </a>
            </div>

            <div>
                <a href="<?php echo e(route('register')); ?>"
                   class="mX-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">
                    <button
                        class="bg-orange-500 hover:bg-orange-700 text-white font-bold py-2 px-4 border border-orange-700 rounded">
                        ثبت نام
                    </button>
                </a>
            </div>

        <?php endif; ?>
    <?php endif; ?>
</div>

        <div class=" mx-16">
            <h1 class="sm:text-xl md:text-2xl lg:text-4xl text-red-700  text-center">Snap Food clone-شبیه سازی اسنپ فود</h1>
        </div>
</div>

<div class="mt-20 ">
    <div class=" w-1/2  mx-auto border border-4 border-blue-400 p-3 bg-white  ">
        <p dir="rtl" class="text-right mt-3">این پروژه در سه قسمت ادمین، فروشنده و مشتری طراحی گردیده است. که در قسمت ادمین داده
            های پایه ای تکمیل می گردد و در قسمت فروشنده یا رستوران دار غذا ها تعریف می شود و اطلاعات رستوران و غذا ها
            تکمیل می
            گردد در قسمت مشتری که به صورت API تعریف شده است امکان ثبت نام، احراز هویت و ایجاد سبد خرید بپردازد.
             از طریق نرم افزارهای postman, insomnia امکان پذیر می باشد.
            فرانت این پروژه tailwind است.
        </p>
        <p dir="rtl" class="text-right mt-20">
            تست مسیرهای API :
        </p>
        <p>
            Route::post('/register',[AuthController::class,'register']);<br>
            Route::post('/login',[AuthController::class,'login']);<br>
            Route::get('/addresses', [AddressUserController::class,'index']);<br>
            Route::post('/address/store', [AddressUserController::class,'store']);<br>
            Route::put('/address/update/{id}', [AddressUserController::class,'update']);<br>

            Route::put('/users/update/{user}',[UserController::class,'update']);<br>
            Route::get('/restaurants',[RestaurantController::class,'index']);<br>
            Route::get('/restaurant/{restaurant}',[RestaurantController::class,'show']);<br>

            //foods<br>
            Route::get('/foods',[FoodController::class,'index']);<br>
            Route::get('/restaurants/{restaurant}/foods',[FoodController::class,'show']);<br>
            Route::get('/foods/{food}',[FoodController::class,'show']);<br>
            Route::get('/restaurants/{restaurant}/foods',[FoodController::class,'showRestaurantFoods']);<br>


            //carts<br>
            Route::post('/cart_items/add', [CartController::class,'store']);<br>
            Route::get('/cart_items',[CartController::class,'index']);<br>
            Route::put('/cart_items/update/{id}', [CartController::class,'update']);<br>
            //    Route::get('/carts/{cart}',[CartController::class,'show']);<br>
            Route::delete('/cart_items/destroy/{id}',[CartController::class,'destroy']);<br>
            Route::get('/carts/confirm_cart',[CartController::class,'confirmCart']);<br>
            Route::delete('/carts/destroy_cart/{cart_number}',[CartController::class,'destroyCart']);<br>
            Route::get('/carts',[CartController::class,'cartIndex']);<br>

            //orders<br>
            Route::get('/orders/payment_order/{cart_number}/{restaurant_id}', [OrderController::class,'paymentOrder']);<br>




            //comment<br>
            Route::post('/comments/add/{order}', [CommentController::class,'store']);<br>

            //reply<br>
            Route::post('/replies/add/{comment}', [ReplyController::class,'store']);<br>

            //near Restaurants<br>
            Route::get('/near_restaurants',[RestaurantController::class,'nearRestaurant']);<br>


            //logout<br>
            Route::post('/logout',[AuthController::class,'logout']);<br>
        </p>
        <p dir="rtl" class="text-right mt-20">
            دسترسی به یوزرها:
        </p>
        <p class="text-left">
            admin <br>
            user:admin@a.com<br>
            password:12345678<br><br>

            seller<br>
            user:seller@a.com<br>
            password:12345678<br><br>

            customer<br>
            user:api@a.com<br>
            password:12345678<br><br>

            developer: Hamed Ebrahimzadeh
        </p>

    </div>

</div>


</body>
</html>
<?php /**PATH D:\laravel projects\snapfoodclone\resources\views/welcome.blade.php ENDPATH**/ ?>