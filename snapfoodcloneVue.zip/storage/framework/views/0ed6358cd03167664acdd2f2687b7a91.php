<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Foods')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php $i=1 ?>
    <div class="py-12 ">
        <div class="mb-6 w-1/2 mx-auto ">



            <form action="<?php echo e(route('seller.food.filter')); ?>"
                  method="post">
                <?php echo csrf_field(); ?>

                <label class="block mb-2 text-sm font-medium text-green-700 dark:text-green-500">food category</label>
                <select name="food_category"
                        id="<?php if(empty($errors->first('food_category'))): ?> success <?php else: ?> error  <?php endif; ?>"
                        class="<?php if(empty($errors->first('food_category'))): ?> bg-green-50 border border-green-500 text-green-900 dark:text-green-400 placeholder-green-700 dark:placeholder-green-500 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5 dark:bg-gray-700 dark:border-green-500
                           <?php else: ?> bg-red-50 border border-red-500 text-red-900 placeholder-red-700 text-sm rounded-lg focus:ring-red-500 dark:bg-gray-700 focus:border-red-500 block w-full p-2.5 dark:text-red-500 dark:placeholder-red-500 dark:border-red-500
                           <?php endif; ?>">

                    <option value="" disabled>select one ...</option>
                    <?php $__currentLoopData = $food_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($food_category->id); ?>"><?php echo e($food_category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>



                <button type="submit"
                        class="bg-transparent hover:bg-red-500 text-red-700 font-semibold hover:text-white py-2 px-4 m-1 border border-red-500 hover:border-transparent rounded">
                    go
                </button>


            </form>



        </div>
        <div class=" w-full ">

            <table class="w-3/4 mx-auto text-xl">
                <thead class=" text-gray-700 uppercase bg-gray-100">
                <tr class="">
                    <th class="px-6 py-3 text-center rounded-l-lg">#</th>

                    <th class="px-6 py-3 text-center rounded-l-lg">name</th>
                    <th class="px-6 py-3 text-center rounded-l-lg">food category</th>
                    <th class="px-6 py-3 text-center rounded-l-lg">materials</th>
                    <th class="px-6 py-3 text-center rounded-l-lg">image</th>
                    <th class="px-6 py-3 text-center rounded-l-lg">price</th>
                    <th class="px-6 py-3 text-center rounded-l-lg">coupon</th>
                    <th class="px-6 py-3 text-center rounded-l-lg">food party</th>
                    <th class="px-6 py-3 text-center rounded-l-lg">restaurant</th>
                    <th class="px-6 py-3 text-center rounded-l-lg">restaurant category</th>

                    <th class="px-6 py-3 text-center"></th>
                    <th class="px-6 py-3 text-center"></th>
                    <th class="px-6 py-3 text-center rounded-r-lg"></th>

                </tr>
                </thead>
                <tbody>
                
                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="border-b even:bg-blue-200">
                        <td class="px-6 py-3 text-center"><?php echo e($i++); ?></td>
                        <td class="px-6 py-3 text-center"><?php echo e($food->name); ?></td>

                        <td class="px-6 py-3 text-center"><?php echo e($food->foodCategory->name); ?></td>
                        <td class="px-6 py-3 text-center"><?php echo e($food->materials); ?></td>
                        <td class="px-6 py-3 text-center"><img src="<?php echo e($food->profile_image_url); ?>" onclick="showModal('<?php echo e($food->profile_image_url); ?>')" /></td>
                        <td class="px-6 py-3 text-center"><?php echo e($food->price); ?></td>
                        <td class="px-6 py-3 text-center"><?php echo e($food->coupon->code); ?></td> <td class="px-6 py-3 text-center"><?php echo e($food->foodParty->name); ?></td> <td class="px-6 py-3 text-center"><?php echo e($food->restaurant->name); ?></td>

                        
                        
                        
                        
                        
                        
                        
                        
                        <td class="px-6 py-3 text-center">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$food)): ?>
                                <a href="<?php echo e(route('seller.food.edit',$food->id)); ?>" class="mx-2">
                                    <button type="submit"
                                            class="bg-transparent hover:bg-green-500 text-green-700 font-semibold hover:text-white py-2 px-4 m-1 border border-green-500 hover:border-transparent rounded">
                                        Edit
                                    </button>
                                </a>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-3 text-center">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$food)): ?>
                                <form action="<?php echo e(route('seller.food.destroy',$food->id)); ?>"
                                      method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit"
                                            class="bg-transparent hover:bg-red-500 text-red-700 font-semibold hover:text-white py-2 px-4 m-1 border border-red-500 hover:border-transparent rounded">
                                        Delete
                                    </button>


                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>
            <div class="w-1/6 mx-auto ">
                <?php echo e($foods->links()); ?>

            </div>
        </div>

    </div>

    <!-- The Modal -->
    <div id="modal"
         class="hidden fixed top-0 left-0 z-80 w-screen h-screen bg-black/70 flex justify-center items-center">

        <!-- The close button -->
        <a class="fixed z-90 top-6 right-8 text-white text-5xl font-bold" href="javascript:void(0)"
           onclick="closeModal()">&times;</a>

        <!-- A big image will be displayed here -->
        <img id="modal-img" class="max-w-[800px] max-h-[600px] object-cover" />
    </div>

    <script>
        // Get the modal by id
        var modal = document.getElementById("modal");

        // Get the modal image tag
        var modalImg = document.getElementById("modal-img");

        // this function is called when a small image is clicked
        function showModal(src) {
            modal.classList.remove('hidden');
            modalImg.src = src;
        }

        // this function is called when the close button is clicked
        function closeModal() {
            modal.classList.add('hidden');
        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\laravel projects\snapfoodclone\resources\views/food/index.blade.php ENDPATH**/ ?>