// src/main.js
import { createApp } from 'vue'
// import App from './App.vue'
import App from '../resources/js/app.js'

import './index.css'

createApp(App).mount('#app')
